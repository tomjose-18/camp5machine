﻿using StudentRecordManagementSystem.Models;
using System.Data;
using System.Data.SqlClient;

namespace StudentRecordManagementSystem.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly string connectionString;

        public UserRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public int? GetRoleIdByCredentials(string username, string password)
        {
            int? roleId = null;

            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("sp_GetRoleIdByCredentials", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Adding parameters
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    // Output parameter for RoleId
                    var roleIdParam = new SqlParameter("@RoleId", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(roleIdParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    // Retrieve RoleId from output parameter
                    roleId = roleIdParam.Value as int?;
                }
            }

            return roleId;
        }
    }
    }

