﻿using StudentRecordManagementSystem.Models;
using System.Data.SqlClient;
using System.Data;

namespace StudentRecordManagementSystem.Repository
{
    public class StudentRepositoryImp : IStudentRepository
    {
        private readonly string connectionString;

        public StudentRepositoryImp(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public void AddStudent(Student student)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("sp_AddStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new SqlParameter("@Id", student.Id));
                    command.Parameters.Add(new SqlParameter("@Name", student.Name));
                    command.Parameters.Add(new SqlParameter("@MathsMark", student.MathsMark));
                    command.Parameters.Add(new SqlParameter("@PhysicsMark", student.PhysicsMark));
                    command.Parameters.Add(new SqlParameter("@ChemistryMark", student.ChemistryMark));
                    command.Parameters.Add(new SqlParameter("@EnglishMarks", student.EnglishMarks));
                    command.Parameters.Add(new SqlParameter("@ProgrammingMarks", student.ProgrammingMarks));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public IEnumerable<Student> GetAllStudentDetails()
        {
            var students = new List<Student>();

            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("sp_DisplayAllStudentDetails", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var student = new Student
                            {
                                Id = reader.GetInt32(0),  // Id
                                RollNumber = reader.GetInt32(1),  // RollNumber
                                Name = reader.GetString(2),  // Name
                                MathsMark = reader.GetInt32(3),  // MathsMark
                                PhysicsMark = reader.GetInt32(4),  // PhysicsMark
                                ChemistryMark = reader.GetInt32(5),  // ChemistryMark
                                EnglishMarks = reader.GetInt32(6),  // EnglishMarks
                                ProgrammingMarks = reader.GetInt32(7)  // ProgrammingMarks
                            };
                            students.Add(student);
                        }
                    }
                }
            }

            return students;
        }
    }
}
