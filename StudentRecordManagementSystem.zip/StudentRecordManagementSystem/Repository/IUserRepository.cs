﻿using StudentRecordManagementSystem.Models;

namespace StudentRecordManagementSystem.Repository
{
    public interface IUserRepository
    {
        int? GetRoleIdByCredentials(string username, string password);
    }
}
