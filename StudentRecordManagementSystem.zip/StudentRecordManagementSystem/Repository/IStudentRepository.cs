﻿using StudentRecordManagementSystem.Models;

namespace StudentRecordManagementSystem.Repository
{
    public interface IStudentRepository
    {
        IEnumerable<Student> GetAllStudentDetails();
        void AddStudent(Student student);
    }
}
