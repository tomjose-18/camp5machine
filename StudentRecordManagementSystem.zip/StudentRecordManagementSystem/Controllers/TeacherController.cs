﻿using Microsoft.AspNetCore.Mvc;
using StudentRecordManagementSystem.Models; // Adjust this based on your namespace
using StudentRecordManagementSystem.Repository;
using System.Collections.Generic;

namespace StudentRecordManagementSystem.Controllers
{
    public class TeacherController : Controller
    {
        private readonly IStudentRepository _studentRepository;

        public TeacherController(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public IActionResult Index()
        {
            // Retrieve all student records
            IEnumerable<Student> studentRecords = _studentRepository.GetAllStudentDetails();

            // Pass the records to the view
            return View(studentRecords);
        }

        [HttpGet]
        public IActionResult AddStudent()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddStudent(Student student)
        {
            if (ModelState.IsValid)
            {
                // Add the student to the repository
                _studentRepository.AddStudent(student);
                return RedirectToAction("Index");
            }

            return View(student);
        }
    }
}
