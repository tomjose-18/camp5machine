﻿using Microsoft.AspNetCore.Mvc;
using StudentRecordManagementSystem.Repository;

namespace StudentRecordManagementSystem.Controllers
{
    public class StudentController : Controller
    {
        private readonly IUserRepository _userRepository;

        public StudentController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public IActionResult Index()
        {
            // You can retrieve the logged-in student's data here if necessary
            // For example, retrieving marks
            /* Get the student's ID from session or claims */
            //var marks = _userRepository.GetStudentMarks(studentId); // Implement this method in the repository
            return View();
        }
    }
}
