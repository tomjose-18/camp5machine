﻿using Microsoft.AspNetCore.Mvc;
using StudentRecordManagementSystem.Repository;

namespace StudentRecordManagementSystem.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserRepository _userRepository;

        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string username, string password)
        {
            // Check user credentials and get RoleId
            var roleId = _userRepository.GetRoleIdByCredentials(username, password);

            if (roleId.HasValue)
            {
                // Redirect based on RoleId
                if (roleId.Value == 1)
                {
                    return RedirectToAction("Index", "Teacher");
                }
                else if (roleId.Value == 2)
                {
                    return RedirectToAction("Index", "Student");
                }
            }

            // Invalid credentials
            ModelState.AddModelError(string.Empty, "Invalid username or password.");
            return View();
        }

        public IActionResult Logout()
        {
            // Implement logout logic here (e.g., clearing session)
            return RedirectToAction("Login");
        }
    }
}
