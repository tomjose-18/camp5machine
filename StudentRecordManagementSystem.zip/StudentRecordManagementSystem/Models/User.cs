﻿namespace StudentRecordManagementSystem.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }  // Store hashed passwords
        public int? RoleId { get; set; }  // Nullable in case user has no role

        public virtual Role Role { get; set; }  // Navigation property
    }
}
