﻿namespace StudentRecordManagementSystem.Models
{
    public class UserViewModel
    {
        public int? RoleId { get; set; }
        public int? StudentId { get; set; }
        public List<MarkViewModel> Marks { get; set; }
    }
}
