﻿namespace StudentRecordManagementSystem.Models
{
    public class Student
    {
        public int Id { get; set; }  // Unique identifier for each student
        public int RollNumber { get; set; }  // 5-digit roll number (auto-generated)
        public string Name { get; set; }  // Student's name
        public int MathsMark { get; set; }  // Marks in Maths
        public int PhysicsMark { get; set; }  // Marks in Physics
        public int ChemistryMark { get; set; }  // Marks in Chemistry
        public int EnglishMarks { get; set; }  // Marks in English
        public int ProgrammingMarks { get; set; }  // Marks in Programming
    }
}
