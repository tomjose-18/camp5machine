﻿namespace StudentRecordManagementSystem.Models
{
    public class MarkViewModel
    {
        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
        public int Marks { get; set; }
    }
}
