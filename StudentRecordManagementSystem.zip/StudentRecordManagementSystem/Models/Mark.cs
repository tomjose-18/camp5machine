﻿namespace StudentRecordManagementSystem.Models
{
    public class Mark
    {
        public int MarksId { get; set; }
        public int StudentId { get; set; }
        public int SubjectId { get; set; }
        public int Marks { get; set; }  // Must be between 1 and 100

        public virtual Student Student { get; set; }  // Navigation property
        public virtual Subject Subject { get; set; }  // Navigation property
    }
}
