﻿namespace StudentRecordManagementSystem.Models
{
    public class StudentRecord
    {
        public string RollNumber { get; set; } // Change to string to match CHAR(5)
        public string Name { get; set; }
        public string SubjectName { get; set; }
        public int Marks { get; set; }
    }
}
